The Magenta JavaScript libraries are now at https://github.com/tensorflow/magenta-js.
