Source of images:

golden_gate
https://commons.wikimedia.org/wiki/File:Golden_Gate_Bridge_from_Battery_Spencer.jpg

colva_beach
https://commons.wikimedia.org/wiki/File:Colva_beach_area.jpg

statue_of_liberty
https://commons.wikimedia.org/wiki/File:NY_Statue_of_Liberty_-_4067353996.jpg

eiffel_tower
https://commons.wikimedia.org/wiki/File:The_Eiffel_Tower_of_French.jpg
