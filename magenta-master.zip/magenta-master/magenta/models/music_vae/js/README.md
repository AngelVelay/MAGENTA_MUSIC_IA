[MusicVAE.js](https://goo.gl/magenta/musicvae-js) is now in the Magenta JavaScript respository at https://github.com/tensorflow/magenta-js.
